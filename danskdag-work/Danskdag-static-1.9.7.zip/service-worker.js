const MANIFEST={"/index.html":"3c344abd4570404481f9bc09225872d1a0aeb177f994d88bc3a0e1e32d125135","/manifest.webmanifest":"25055480accb3438b049cc1f28558d5fb7e5ce64231600ab46143419feca62b7","/icon.svg":"a6e623571b7305903abbe9059384dcc233b6ebee7451d90eee27ed981bd44b91","/icon-192.png":"5c2587d996df4c5abb4bffead54c821743aed45fa8e5e13e8c9fe37e09983bf2","/icon-512.png":"dbb222bda4cd44b333509afec4848d33aec4432f4095683c8c8dcc0e831e575e","/flag-dk.svg":"a9db2939c6736db071b3cf6f01a435ccf310d020b6c8e7371bbbfc2e88a714ce"};
const CACHE='danskdag-static-1492c073d39a1e6939da',NETWORK_TIMEOUT=3000;
async function loadAsset(path,cache){
 const response=await fetch(new URL(path==='/index.html'?'/':path,self.location.origin).href,{cache:'reload',credentials:'same-origin'});
 if(!response.ok||response.redirected)throw Error('Static asset unavailable: '+path);
 const digest=await crypto.subtle.digest('SHA-256',await response.clone().arrayBuffer());
 const hash=Array.from(new Uint8Array(digest),b=>b.toString(16).padStart(2,'0')).join('');
 if(hash!==MANIFEST[path])throw Error('Static asset hash mismatch: '+path);
 await cache.put(path,response.clone());return response;
}
// A slow or hanging connection must not keep the learner waiting: after NETWORK_TIMEOUT the verified cached copy is used.
async function fetchWithTimeout(href,options){
 if(typeof AbortController!=='function'||typeof setTimeout!=='function')return fetch(href,options);
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),NETWORK_TIMEOUT);
 try{return await fetch(href,{...options,signal:controller.signal});}finally{clearTimeout(timer);}
}
async function isAppPage(response){
 if(!response.ok||response.redirected||!/^text\/html\b/i.test(response.headers.get('content-type')||''))return false;
 const reader=response.clone().body?.getReader();if(!reader)return false;
 const decoder=new TextDecoder();let head='';
 try{while(head.length<4096){const part=await reader.read();if(part.done)break;head+=decoder.decode(part.value,{stream:true});}}finally{reader.cancel().catch(()=>{});}
 return head.includes('<meta name="danskdag-version"');
}
self.addEventListener('install',event=>event.waitUntil((async()=>{
 try{const cache=await caches.open(CACHE);await Promise.all(Object.keys(MANIFEST).map(path=>loadAsset(path,cache)));await self.skipWaiting();}
 catch(error){await caches.delete(CACHE);throw error;}
})()));
self.addEventListener('activate',event=>event.waitUntil((async()=>{
 for(const key of await caches.keys())if(key.startsWith('danskdag-static-')&&key!==CACHE)await caches.delete(key);
 await self.clients.claim();
})()));
self.addEventListener('fetch',event=>{
 if(event.request.method!=='GET')return;
 const url=new URL(event.request.url),pathname=['/','/open'].includes(url.pathname)?'/index.html':url.pathname;
 if(url.origin!==self.location.origin||!Object.hasOwn(MANIFEST,pathname))return;
 event.respondWith((async()=>{
  if(pathname==='/index.html'){
   try{
    const target=new URL(url.pathname==='/open'||url.pathname==='/index.html'?'/':url.pathname,url.origin);target.search=url.search;
    const response=await fetchWithTimeout(target.href,{cache:'no-cache',credentials:'same-origin'});
    if(await isAppPage(response))return response;
   }catch{}
  }
  const cache=await caches.open(CACHE);return await cache.match(pathname)||loadAsset(pathname,cache);
 })());
});
